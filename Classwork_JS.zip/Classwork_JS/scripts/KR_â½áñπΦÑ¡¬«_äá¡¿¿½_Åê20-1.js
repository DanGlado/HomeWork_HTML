// № 1 # Triangle
let resh = "";
let x = 1;
while (x<8){
    resh = resh + "#"
    console.log(resh);
    x++;
}

// № 2 FizzBuzz
let F = "Fizz";
let B = "Buzz";
let FB = "FizzBuzz";
for(let i=1; i<100; i++){
    if (i%5==0 && i%3 != 0) {
        console.log(B);
    } else if (i%3==0 && i%5 != 0) {
        console.log(F);
    } else if (i%3==0 && i%5==0){
        console.log("FB");
    } else {
        console.log(i);
    }
}

// № 3 Chess_desk

let str_ch = " # # # # # # # #";
let str_nch = "# # # # # # # # ";
for(let i=1; i<9; i++){
    if (i%2 == 0){
        console.log(str_ch);
    } else if (i%2 == 1){
        console.log(str_nch);
    }
}

// № 4 Minimum
function min(n, m){
    if (n > m){
        console.log("min: ", m);
        return m;
    } else if (n < m){
        console.log("min: ", n);
        return n;
    } else {
        console.log("Elements equals ");
    }
}

// Examples 
// min(56, 10)
// min(10,10)

// № 5 Counting bobs
function countBs(str, count=0, B=0){
    let symbols = str.length;
    while (count != symbols){
        if (str.charAt(count)=="B"){
            B++
        }
        count++
    }
    console.log(B);
    return B
}

function countChar(str, symb, count=0, k=0){
    let symbols = str.length;
    while (count != symbols){
        if (str.charAt(count)==symb){
            k++;
        }
        count++
    }
    console.log(k);
    return k;
}
//  Examples
// countBs("BtoBtoBbBBt")
// countChar("BtoBtoBbBBt", "t")

// № 6 Sum range
function range(start, end, step){
    let massiv = [];
    while (start != end+step){
        massiv.push(start);
        start=start+step;
    }
    console.log(massiv);
    return massiv;
}

function arraySum(array){
var sum = 0;
for(var i = 0; i < array.length; i++){
    sum += array[i];
    }
console.log(sum);
}


// Examples

// range(5, 2, -1)  Output: [5, 4, 3, 2]
// range(2, 8, 2)  Output: [2, 4, 6, 8]
// arraySum(range(5, 2, -1))  Output: 14
// arraySum(range(2, 8, 2))  Output: 20


// № 7 Reverse Massive
function reverseArray(array){
    let new_arr = [];
    for (let i = 0; i < array.length; i += 1) {
        new_arr.unshift(array[i]);
    }
    console.log(new_arr)
    console.log(array)
    return new_arr
}


function reverseArrayInPlace(arr) {
    for(let i = 0, j = arr.length-1; i < j; i++, j--){
        [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    console.log(array)
    return array
  }


let array = ['one', 'two', 'three'];

// reverseArray(array)

reverseArrayInPlace(array)