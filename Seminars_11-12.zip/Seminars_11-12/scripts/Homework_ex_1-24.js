// № 1
console.log("Задание 1")
let city1 = {
    name: 'ГородMoscow',
    population: 10000000
};

// № 2
console.log("Задание 2")
let city2 = {
    name: 'ГородM',
    population: 1e7
};

// № 3
console.log("Задание 3");
function getName() {
    alert(this.name)
}

city1.getName = getName;

city2.getName = getName;

city1.getName();
city2.getName();

// № 4
console.log("Задание 4")
function exportStr(){
    alert(`name=${this.name}\npopulation=${this.population}`)
}

city1.exportStr = exportStr;

city2.exportStr = exportStr;

city1.exportStr();
city2.exportStr();

// № 5
console.log("Задание 5")
function getObj() {
    return this;
}

city1.getCity = getObj;

city2.getCity = getObj;

alert(city1.getCity(), city2.getCity())


// № 6
console.log("Задание 6")
function method1(){
    return this
}
function method2(){
    return this
}
function method3(){
    return alert('method3')
}
const obj = {};
obj.method1 = method1;
obj.method2 = method2;
obj.method3 = method3;

obj.method1().method2().method3()

// №7
console.log("Задание 7\n\n")
let d1 = [45,78,10,3];
d1[7] = 100;
console.log(d1, d1[6], d1[7])

// №8
console.log("Задание 8\n\n")
let d2 = [45,78,10,3];
let sum2 = 0;
for (i=0; i < d2.length; i++){
    sum2 += d2[i]
}
console.log(sum2)

// №9
console.log("Задание 9\n\n")
let d3 = [45,78,10,3];
d3[7]=100;
let sum3 = 0;
for (elem in d3){
    sum3 += d3[elem]
    console.log(d3[elem])
}
console.log(sum3, d3)

// №10
console.log("Задание 10\n\n")
let d4 = [45,78,10,3];
function my(a, b){
    if (a>=b){
        return -1;
    }
}
console.log(d4.sort(my))

// №11
console.log("Задание 11\n\n")
d5 = [];
for (i=0; i<=2; i++){
    d5[i] = []
    for (k=0; k<=3; k++){
        d5[i][k] = 5;
    }
}
console.log(d5)

// №12
console.log("Задание 12\n\n")
function Vector(x,y) {
    this.x = x;
    this.y = y;
    this.length = (this.x**2 + this.y**2)**0.5;
  }
Vector.prototype.plus = function plus(otherVector) {
  let x = this.x + otherVector.x;
  let y = this.y + otherVector.y;
  return new Vector(x, y);
};
Vector.prototype.minus = function minus(otherVector) {
  let x = this.x - otherVector.x;
  let y = this.y - otherVector.y;
  return new Vector(x, y);
};

console.log(new Vector(1, 2).plus(new Vector(2, 3)));
console.log(new Vector(1, 2).minus(new Vector(2, 3)));
console.log(new Vector(3, 4).length);

// №13
console.log("Задание 13\n\n")
function TextCell(text){
    this.text = text;
}

function StretchCell(inner, width, height){
    this.text = inner.text;
    this.width = width;
    this.height = height;

    this.minWidth = function () {
        return Math.max(
            this.text.split('\n').sort(
                function(a,b){
                    return b.length - a.length})[0]
                .length,
            this.width)
    }

    this.minHeight = function () {
        return Math.max(this.text.split('\n').length, this.height)
    }

    this.draw = function(width, height){
        text_joined = this.text.split('\n').join('');
        text_joined += " ".repeat(width*height - text_joined.length);
        cell = [];
        for (let i=0; i<height; i++){
            s = '';
            for (let j=0; j<width; j++){
                s += text_joined[i*width + j];
            }
            cell.push(s);
        }
        return cell;
    }
}

let scell = new StretchCell(new TextCell("abc\nde\nefg"), 1, 2);
console.log("Min width: ", scell.minWidth());
console.log("Min height: " ,scell.minHeight());
console.log("Draw: ", scell.draw(5,3));

// StretchCell
// №14
console.log("Задание 14\n\n")
function StretchCell(inner, width, height) {
    this.inner = inner;
    let text = this.inner.text;
    if (text.length < height) {
        while (height - text.length > 0) {
            text = text.concat([""]);
            --height;
        }
    }
    this.inner.text = text.map(function (line) {
        if (line.length < width) {
            return line.concat(repeat(" ", width - line.length));
        } else {
            return line;
        }
    });
}

StretchCell.prototype.minHeight = function () {
    return this.inner.minHeight();
};
StretchCell.prototype.minWidth = function () {
    return this.inner.minWidth();
};
StretchCell.prototype.draw = function (w, h) {
    return this.inner.draw(w, h);
};

// ---------------------------------------
// Sequence interface
function ArraySeq(a) {
    this.container = a;
}
ArraySeq.prototype.begin = function () {
    this.curr_idx = 0;
    return this.curr_idx;
};
ArraySeq.prototype.end = function () {
    return this.container.length;
};
ArraySeq.prototype.next = function () {
    ++this.curr_idx
    return this.curr_idx;
};
ArraySeq.prototype.valueAt = function (iterator) {
    return iterator < this.container.length ? this.container[iterator] : undefined;
};


function RangeSeq(from, to) {
    this.container = [];
    for(let i=from; i<=to; ++i) {
        this.container.push(i);
    }
}
RangeSeq.prototype = Object.create(ArraySeq.prototype);


function logFive(seq) {
    let c = 0;
    for(let i=seq.begin(); i!=seq.end() && c<5; i=seq.next(), ++c) {
        console.log(seq.valueAt(i));
    }
}

logFive(new ArraySeq([1, 2]));
logFive(new RangeSeq(100, 1000));

// № 15
console.log("Задание 15\n\n")
function Cards(from, to){
    this.from = from;
    this.to = to;

    this.show = function() {
        alert(`From ${from} to ${to}`)
    };
}

let c1 = new Cards("Екатеринбург", "Москва")

c1.show()


// № 16
console.log("Задание 16\n\n")
class Human {
    constructor(name, age, height){
        this.name = name;
        this.age = age;
        this.height = height;
    }
    getInfo() { alert(`${this.name}, ${this.age}, ${this.height}`); }
    get firstname() {
        alert(this.name)
    }
}

let Kol = new Human("Коля", 23, 180);
let Dash = new Human("Даша", 19, 170);
let Van = new Human("Ваня", 18, 192);
let Pet = new Human("Петя", 45, 178);
let Vas = new Human("Вася", 34, 197);
let Jon = new Human("Джони", 40, 168);
let Kat = new Human("Катя", 37, 160);
let Pet2 = new Human("Петя", 29, 200);
let Son = new Human("Соня", 21, 172);
let Jen = new Human("Женя", 25, 175);

let humans = [Kol, Dash, Van, Pet, Vas, Jon,
              Kat, Pet2, Son, Jen];
// console.log(humans)
Kol.getInfo(); // Коля, 23, 180
Kol.firstname // Коля

// № 17
console.log("Задание 17\n\n")
function sortByName(array, reverse=false) {
    if (!reverse){
        return array.sort()
    } else{
        array = array.sort()
        return array.reverse()
    }

}
function sortByHeight(array, reverse=false) {
    if (!reverse){
        return array.sort()
    } else{
        array = array.sort()
        return array.reverse()
    }
}
let arr1=["Bob", "Bully", "Amy"]
let arr2=[5,9,0,3,6]

alert(sortByHeight(arr2)) // 0,3,5,6,9
alert(sortByHeight(arr2, true)) // 9,6,5,3,0
// № 18
console.log("Задание 18\n\n")
const dt1 = new Date('January 1, 2045 00:00:00');
alert(dt1) // Sun Jan 01 2045 00:00:00 GMT+0300 (Москва, стандартное время)

// № 19
console.log("Задание 19\n\n")
const dt_now = new Date('November 27, 2021 15:30:00');
const dt_old = new Date('January 1, 1970 00:00:00');
const dt2 = dt_now - dt_old;
console.log(dt2/1000);  // 1638027000

// № 20
console.log("Задание 20\n\n")
function getDays(year, month) {
    monthNum =  new Date(Date.parse(month +" 1,"+year)).getMonth()+1
    return new Date(year, monthNum, 0).getDate();
}

alert(getDays(2021, 11))


// № 21
console.log("Задание 21\n\n(на веб-странице)");

function calendar(year, month){
  
    days = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];

    let date = new Date(year, month-1, 0);
    empty_cells = (date.getDay() - 7) % 7 + 7;
    parent = document.createElement("div");
    parent.style.display = "grid";
    parent.style.gridTemplateColumns = "repeat(7, 50px)";
    parent.style.textAlign = "right";

    
    days.forEach(element => {
        label = document.createElement("div");
        label.innerHTML = element;
        parent.appendChild(label);
    });

    for (let i = 0; i < empty_cells; i++){
        parent.appendChild(document.createElement("div"));
    }

    for (let i = 0; i < date.getDate(); i++){
        day = document.createElement("div");
        day.innerHTML = `${i+1}`;
        parent.appendChild(day);
    }

    document.body.append(parent);
}

calendar(2021, 10);

// № 22
console.log('Задание 22\n\n');

Number.prototype.isOdd = function(){
    return this % 2 != 0;
}

a = new Number(5);
b = new Number(6);
console.log(a.isOdd());
console.log(b.isOdd());

// № 23
console.log('Задание 23\n\n');

function Cepochka(val){
    this.val = val,

    this.add = function(a){
        this.val += a;
        return this;
    },

    this.difference = function(a){
        this.val -= a;
        return this;
    },

    this.multiply = function(a){
        this.val *= a;
        return this;
    },
    
    this.div = function(a){
        this.val /= a;
        return this;
    }
}

example = new Cepochka(10).add(7).difference(2).multiply(2).div(5);
console.log(example.val);


// № 24
console.log('Задание 24\n');

function Unit(x, y){
    this.x = x;
    this.y = y;
}

Unit.prototype = {
    get X() {
        return this.x;
    },
    get Y() {
        return this.y;
    },
    set X(val) {
        this.x = val;
    },
    set Y(val) {
        this.y = val;
    }
}

function Fighter(power){
    this.power = power;
}

Fighter.prototype = Unit.prototype;
Fighter.prototype += {
    get power() {
        return power;
    },
    set power(value) {
        this.power = value;
    }
}

let fighter = new Fighter(5);
fighter.X = 10;
fighter.Y = 20;
console.log(fighter.X, fighter.Y);
