console.log('Задание 24\n');

function Unit(x, y){
    this.x = x;
    this.y = y;
}

Unit.prototype = {
    get X() {
        return this.x;
    },
    get Y() {
        return this.y;
    },
    set X(val) {
        this.x = val;
    },
    set Y(val) {
        this.y = val;
    }
}

function Fighter(power){
    this.power = power;
}

Fighter.prototype = Unit.prototype;
Fighter.prototype += {
    get power() {
        return power;
    },
    set power(value) {
        this.power = value;
    }
}

let fighter = new Fighter(5);
fighter.X = 10;
fighter.Y = 20;
console.log(fighter.X, fighter.Y);
