// № 1

let city1 = {
    name: 'ГородMoscow',
    population: 1000000
};

// № 2

let city2 = {
    name: 'ГородM',
    population: 1e6
};

// № 3

function getName() {
    alert(this.name)
}

city1.getName = getName;

city2.getName = getName;

city1.getName();
city2.getName();

// № 4

function exportStr(){
    alert(`name=${this.name}\npopulation=${this.population}`)
}

city1.exportStr = exportStr;

city2.exportStr = exportStr;

city1.exportStr();
city2.exportStr();

// № 5

function getObj() {
    return this;
}

city1.getCity = getObj;

city2.getCity = getObj;

alert(city1.getCity(), city2.getCity())




// № 15
function Cards(from, to){
    this.from = from;
    this.to = to;

    this.show = function() {
        alert(`From ${from} to ${to}`)
    };
}

let c1 = new Cards("Екатеринбург", "Москва")

c1.show()


// № 16
class Human {
    constructor(name, age, height){
        this.name = name;
        this.age = age;
        this.height = height;
    }
    getInfo() { alert(`${this.name}, ${this.age}, ${this.height}`); }
    get firstname() {
        alert(this.name)
    }
}

let Kol = new Human("Коля", 23, 180);
let Dash = new Human("Даша", 19, 170);
let Van = new Human("Ваня", 18, 192);
let Pet = new Human("Петя", 45, 178);
let Vas = new Human("Вася", 34, 197);
let Jon = new Human("Джони", 40, 168);
let Kat = new Human("Катя", 37, 160);
let Pet2 = new Human("Петя", 29, 200);
let Son = new Human("Соня", 21, 172);
let Jen = new Human("Женя", 25, 175);

let humans = [Kol, Dash, Van, Pet, Vas, Jon,
              Kat, Pet2, Son, Jen];
// console.log(humans)
Kol.getInfo(); // Коля, 23, 180
Kol.firstname // Коля

// № 17
function sortByName(array, reverse=false) {
    if (!reverse){
        return array.sort()
    } else{
        array = array.sort()
        return array.reverse()
    }

}
function sortByHeight(array, reverse=false) {
    if (!reverse){
        return array.sort()
    } else{
        array = array.sort()
        return array.reverse()
    }
}
let arr1=["Bob", "Bully", "Amy"]
let arr2=[5,9,0,3,6]

alert(sortByHeight(arr2)) // 0,3,5,6,9
alert(sortByHeight(arr2, true)) // 9,6,5,3,0
// № 18
const dt1 = new Date('January 1, 2045 00:00:00');
alert(dt1) // Sun Jan 01 2045 00:00:00 GMT+0300 (Москва, стандартное время)

// № 19
const dt_now = new Date('November 27, 2021 15:30:00');
const dt_old = new Date('January 1, 1970 00:00:00');
const dt2 = dt_now - dt_old;
console.log(dt2/1000);  // 1638027000

// № 20
function getDays(year, month) {
    monthNum =  new Date(Date.parse(month +" 1,"+year)).getMonth()+1
    return new Date(year, monthNum, 0).getDate();
}

alert(getDays(2021, 11))


