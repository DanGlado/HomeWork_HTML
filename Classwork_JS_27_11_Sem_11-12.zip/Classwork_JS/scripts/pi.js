alert("Hello world");

// 1 string comment

/*

    many strings
    comm

    */

let nameOfvariadle;

var nameOfvariableOld;

let nameOfvariadle2="String",
nameOfvariadle3 = 23;

console.log("variable1 " + nameOfvariadle2)

const CONSTANT_VALUE = 3.14;

// Взаимодействие с пользователем

alert("Всплывающее уведомление")

let userInput = prompt("Введите значение ", 0)
console.log(userInput)

let userInputBoolean = confirm("Вопрос какой-нибудь ");
console.log(userInputBoolean)

// Type Data

// Number
let n1 = 34;
let n2 = 3.4;

console.log(n1)
console.log(n2)

// Постфиксная и префиксная инкрементация и декрементация
let nx = 10;

console.log(nx++);
console.log(nx);
console.log(nx--);
console.log(nx);

// Постфиксная инкр и декрем

// Префиксная и и д

console.log(++nx);
console.log(nx);
console.log(--nx);
console.log(nx)

// Префиксная и и д


// BigInt
// Number имеет значения в диапазоне от -2^53-1 до 2^53-1
let n3 = 44347636462574657625436523764n;
let n4 = 10n;

console.log(n3);
console.log(typeof n4);

// String

let s1 = 'Hi'
let s2 = "Hi"
let s3 = `Hi`;

let Name = "Daniil"
let s4 = `Hi , ${name}`;

console.log(s4);

// Bool

let b1 = true
let b2 = false

let b3 = 25<15;

// null
let n5 = null;


// undefined
let n6;

console.log(`n5-${n5}`)
console.log(`n6-${typeof n6}`)

// -----------------


// Преобразование типов

let n10 = 10;

n10 = String(n10);
console.log(typeof n10)

//boolean

let b4 = Boolean("") // f
let b5 = Boolean(0) // f
let b6 = Boolean("0") // t

let b7 = Boolean(-1) // t

// Преобразование типов в булеан по логике питона

// Logical consistence

// AND
let b8 = b4 && b7;

// OR
let b9 = b8 || b7;
console.log(b8);
console.log(b9);

// IF

if (b4 && b7) {
    alert ("Cond 1");
} else if (b8 || b7) {
    alert("Cond 2");
} else {
    alert("Cond 3");
}

// Ternarnyi operator
let Age = 20;
let accessAllowed = (Age >= 18) ? true : false;

// Switch case

let month = "June";

switch(month){
    case "Jan":
        alert("Winter");
        break;
    case "June":
        alert("Summer")
        break;
    default:
        alert("Некорректное значение месяца");
        break;
}

switch(month){
    case "January":
    case "Febr":
    case "Dec":
        alert("Winter");
        break
    default:
        alert("Incorrect");
        break
}

// Circles
let resh = ""
let x = 1
while (x<7){
    resh = resh + "#"
    console.log(resh)
    x++
}

// DO...While

do {
    console.log(`DO WHILE $(x--)`);
} while (x>100)

// FOR

for(let i=0; i<15; i++){
    console.log(`for i: $(i)`);
}

// BREAK | Continue

// Functions

function showMessage(n1, n2, n3, n4, n5 = "Value_default"){
    // Body
    let retVar = n1+n2+n3+n4+n5;
    return retVar;
}
