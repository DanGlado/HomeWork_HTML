// № 1 # Triangle
let resh = "";
let x = 1;
while (x<8){
    resh = resh + "#"
    console.log(resh);
    x++;
}

// № 2 FizzBuzz
let F = "Fizz";
let B = "Buzz";
let FB = "FizzBuzz";
for(let i=1; i<100; i++){
    if (i%5==0 && i%3 != 0) {
        console.log(B);
    } else if (i%3==0 && i%5 != 0) {
        console.log(F);
    } else if (i%3==0 && i%5==0){
        console.log("FB");
    } else {
        console.log(i);
    }
}

// № 3 Chess_desk

let str_ch = " # # # # # # # #";
let str_nch = "# # # # # # # # ";
for(let i=1; i<9; i++){
    if (i%2 == 0){
        console.log(str_ch);
    } else if (i%2 == 1){
        console.log(str_nch);
    }
}

// № 4 Minimum
function min(n, m){
    if (n > m){
        console.log("min: ", m);
        return m;
    } else if (n < m){
        console.log("min: ", n);
        return n;
    } else {
        console.log("Elements equals ");
    }
}

// Examples 
// min(56, 10)
// min(10,10)

// № 5 Counting bobs
function countBs(str, count=0, B=0){
    let symbols = str.length;
    while (count != symbols){
        if (str.charAt(count)=="B"){
            B++
        }
        count++
    }
    console.log(B);
    return B
}

function countChar(str, symb, count=0, k=0){
    let symbols = str.length;
    while (count != symbols){
        if (str.charAt(count)==symb){
            k++;
        }
        count++
    }
    console.log(k);
    return k;
}
//  Examples
// countBs("BtoBtoBbBBt")
// countChar("BtoBtoBbBBt", "t")

// № 6 Sum range
function range(start, end, step){
    let massiv = [];
    while (start != end+step){
        massiv.push(start);
        start=start+step;
    }
    console.log(massiv);
    return massiv;
}

function arraySum(array){
var sum = 0;
for(var i = 0; i < array.length; i++){
    sum += array[i];
    }
console.log(sum);
}


// Examples

// range(5, 2, -1)  Output: [5, 4, 3, 2]
// range(2, 8, 2)  Output: [2, 4, 6, 8]
// arraySum(range(5, 2, -1))  Output: 14
// arraySum(range(2, 8, 2))  Output: 20


// № 7 Reverse Massive
function reverseArray(array){
    let new_arr = [];
    for (let i = 0; i < array.length; i += 1) {
        new_arr.unshift(array[i]);
    }
    console.log(new_arr)
    console.log(array)
    return new_arr
}


function reverseArrayInPlace(arr) {
    for(let i = 0, j = arr.length-1; i < j; i++, j--){
        [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    console.log(array)
    return array
  }


let array = ['one', 'two', 'three'];

// reverseArray(array)

// reverseArrayInPlace(array)

// № 8 List

let list = {
    value: 1,
    rest: {
        value: 2,
        rest: {
            value:3,
            rest: null
        }
    }
}

console.log(list)

function nth(list, numb, k=0){
    if (k==numb){
        console.log(list.value);
    } else {
        try {
            nth(list.rest, numb, k+1)
        }
        catch {
            return undefined
        }
    }
}


function arrayToList(arr){

    for (let i = arr.length-1; i > -1; i--){
        list = prepend(arr[i], list);
    }
    return list;
}

function prepend(elem, list){
    list = {
        value: elem,
        rest: list
    }
    return list
}

let arr = []

function listToArray(list){
    arr.push(list.value)
    if (list.rest) {
        listToArray(list.rest);
    }
    return arr
}

// nth(list, 2)
// console.log(listToArray(list))
// console.log(arrayToList(listToArray(list)))

// № 9 deepEqual
function deepEqual(val1, val2){
    if (val1 === val2) {
        return true;
    }
    
    if (val1 == null || typeof(val1) != "object" || val2 == null || typeof(val2) != "object"){
        return false;
    }

    let elem1 = 0;
    let elem2 = 0;
    
    for (let elem in val1) {
        elem1 += 1;
    }
    for (let k in val2){
        elem2 += 1;
        if (!(k in val1) || !deepEqual(val1[k], val2[k])) {
            return false;        
        }
    }
    return elem1 == elem2;
}

let list1 = {
    value: 1,
    rest: {
        value: 2,
        rest: {
            value:0,
            rest: null
        }
    }
}

let list2 = {
    value: 1,
    rest: {
        value: 2,
        rest: {
            value:3,
            rest: null
        }
    }
}

// console.log(deepEqual(null, null))  // T
// console.log(deepEqual(list1, list2))  // F
// console.log(deepEqual(0, false))  // F
// console.log(deepEqual(5, 5))  // T
// console.log(deepEqual(5, '5'))  // F
// console.log(deepEqual('Hellow', 'Hellow')) // T

// № 10
let Array = [[1, 2, 3], ["a", "b", "c"], [0, -1, -2]];
const reducer = (previousValue, currentValue) => previousValue.concat(currentValue);

console.log(Array.reduce(reducer));
// expected output: [1, 2, 3, 'a', 'b', 'c', 0, -1, -2]

// № 11
let Ages = [[10, 30], [6, 23], [3, 25], [20], [5, 35]]

function average(array) {
    function plus(a, b) { return a + b; }
    array.forEach((item, index, array) => {
        if (item.length == 1){
            delete array[index]
        } else{
            item = Math.abs(item[0] - item[1]);
            array[index] = item;
        }
    });
    console.log(array)
    console.log(array.reduce(plus))
    console.log(array.length)
    return array.reduce(plus) / array.length;
  }

console.log(average(Ages))

// № 12
let persons_16 = [45, 40, 39];
let persons_17 = [55, 43, 41];
let persons_18 = [60, 46, 49];
let persons_19 = [65, 50, 64];
let persons_20 = [69, 63, 83];
let persons_21 = [72, 68, 87];

function average_cenutury(array) {
    function plus(a, b) { return a + b; }
    return Math.ceil(array.reduce(plus) / array.length);
}

console.log(average_cenutury(persons_16))  // 42
console.log(average_cenutury(persons_17))  // 47
console.log(average_cenutury(persons_18))  // 52
console.log(average_cenutury(persons_19))  // 60
console.log(average_cenutury(persons_20))  // 72
console.log(average_cenutury(persons_21))  // 76


// № 13
function my_every(array, func){
    i = 0;
    while(i < array.length){
        if (!func(array[i])) return false;
        i++;
    }
    return true;
}

function my_some(array, func){
    i = 0;
    while(i < array.length){
        if (func(array[i])) return true;
        i++;
    }
    return false;
}

console.log(my_every([NaN,NaN,NaN],isNaN)); // true
console.log(my_every([NaN,NaN,1],isNaN)); // false

console.log(my_some([6,-9,NaN,2,0],isNaN)); // true
console.log(my_some([1,2,3,4,0],isNaN)); // false


