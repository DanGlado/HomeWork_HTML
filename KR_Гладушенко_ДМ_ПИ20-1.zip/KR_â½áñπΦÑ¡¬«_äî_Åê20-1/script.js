function game(player1, player2){
    // Правила игры.
    alert("Игра Виселица, нужно отгадать слово, вводя буквы");
    // Игрок вводит загаданное слово.
    let word = prompt(`Игрок №${player1} загадай слово`, "Виселицарь");
    word = word.toLowerCase();
    // Создаём массив в котором заменяем буквы в слове на  " _ "
    let crossedOutLettersInAWord = [];
    for (let i = 0; i < word.length; i++) {
        crossedOutLettersInAWord[i] = " _ ";
    }
    // Цикл, в котором создаются переменные со значениями, равными порядковому символу из выбранного слова,
    // это нужно для будущего сравнения. 
    // Если введён символ которого нет в слове, то будут сгорать колличество попыток.
    for (let g = 0; g < word.length; g++){
        eval("let id_"+g+"="+g);
        id_0 = word[0];
        id_1 = word[1];
        id_2 = word[2];
        id_3 = word[3];
        id_4 = word[4];
        id_5 = word[5];
        id_6 = word[6];
        id_7 = word[7];
        id_8 = word[8]
        id_9 = word[9]
        id_10 = word[10]
        id_11 = word[11];
        id_12 = word[12]
    }
    // alert([id_0, id_1, id_2, id_3, id_4, id_5, id_6, id_7, id_8, id_9, id_10, id_11, id_12])
    // Создаём переменную с числом букв в выбранном слове.
    // Создаём переменную в которой " _ " изменяет на угаданный символ.
    // Создаём переменную с колличеством попыток.
    let lenWord = word.length;
    let wordGuessedLetters = crossedOutLettersInAWord;
    let numberOfAttempts = 3;
    // Вступление перед началом игры.
    alert("Слово состоит из " + "''" + lenWord + "''" + " букв " + crossedOutLettersInAWord.join("") + " и у Вас есть " + numberOfAttempts + " попытки!");
    // Создаём цикл который выполняется при условии, что количество попыток больше нуля, и количество букв в слове больше нуля
    // При каждой не угаданной букве будет уменьшаться число попыток.
        while ((numberOfAttempts > 0) && (lenWord > 0)) {
    // Создаём переменую которая при помощи функции запрашивает ввести символ который присваивается переменной и при помощи метода переводит символ в нижний риестр.
            let guess = prompt('Укажите пожалуйста одну букву из загаданного слова\nРесский алфавит: а, б, в, г, д, е, ё, ж, з, и, й, к, л, м, н, о, п, р, с, т, у, ф, х, ц, ч, ш, щ, ъ, ы, ь, э, ю, я').toLowerCase();
    // Проверяем на " Отмену "
            if (guess === null) {
                break;
    // Проверяем количество введёных символов: если ведено больше 1 символа, то просим ввести 1.
            } else if (guess.length !== 1) {
                alert('Пожалуйста введите только одну букву!');
    // Цикл, который проверяет есть ли введённый символ в выбраном слове.
            } else {
                for (let p = 0; p < word.length; p++) {
    // В случае если введёный символ введён повторно просим ввести символ повторно
                    if ( guess === wordGuessedLetters[p]) {
                        alert("Такая буква уже отгадана, попробуйте другую!")
                        break;
                    } 
    // В случае если такой символ есть убираем одну букву
                    if ( guess === word[p]) {
                        wordGuessedLetters[p] = guess;
                        lenWord--;
                        restOfLetter = lenWord;
                    }
                }
    // Создаём цикл который проверяет введёный символ с каждой из созданых переменных которая содержит одну букву из выбранного слова. 
                for (let c = 0; c < 1; c++) {
                    if (id_0 === guess || id_1 === guess || id_2 === guess || id_3 === guess || id_4 === guess || id_5 === guess || id_6 === guess
                        || id_7 === guess || id_8 === guess || id_9 === guess || id_10 === guess || id_11 === guess || id_12 === guess){
                        alert("Вы отгадали букву!!! " + wordGuessedLetters.join(" ") + " колличество ваших попыток = " + numberOfAttempts)
                        break;
    // Если при введёный символ не соответствует ни одному значению из переменных убираем одну попытку.                   
                    } else {
                        numberOfAttempts--;
                        alert("Увы такой буквы в слове " + wordGuessedLetters.join(" ") + " нет, колличество ваших попыток = " + numberOfAttempts)
                        break;
                    }
                }
            }               
        }
    // Если слово отгадано выводим поздрравление!
    if (lenWord == 0){
        alert(`Игрок №${player2} отгадал все ${word.length} букв в слове ${wordGuessedLetters.join("")} \n и у него в запасе осталось ещё  + ${numberOfAttempts} попыток!`);
        
    } else {
        alert("У вас закончились попытки и слово не отгаданно попробуйте заново")
    }     
}
// random number (min = 1, max = 2)
let player1 = Math.floor(Math.random() * (2 - 1 + 1) + 1);
let player2;
if (player1 == 1){
    player2 = 2;
} else {
    player2 = 1;
}

game(player1, player2);

let isContinue = confirm("Хотите продолжить игру?");
if (isContinue){
    game(player2, player1);
}

alert("Конец игры")